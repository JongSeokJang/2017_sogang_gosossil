#include "my_solver.h"

// HOMEWORK
void program2_3()
{

}

// HOMEWORK
void program2_2_a()
{
	__int64 start, freq, end;
	float resultTime = 0;

	CHECK_TIME_START;

	// something to do...

	CHECK_TIME_END(resultTime);

	printf("The program2_2_a run time is %f(ms)..\n", resultTime*1000.0);
}

void program2_2_b()
{
	__int64 start, freq, end;
	float resultTime = 0;

	CHECK_TIME_START;

	// something to do...

	CHECK_TIME_END(resultTime);

	printf("The program2_2_b run time is %f(ms)..\n", resultTime*1000.0);
}